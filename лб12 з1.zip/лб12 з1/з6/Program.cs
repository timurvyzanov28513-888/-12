﻿using System;
using System.Linq;
using System.Collections.Generic;

class Department
{
    public string Name { get; set; }
    public List<string> Employees { get; set; }
}

class Program
{
    static void Main()
    {
        List<Department> departments = new List<Department>
        {
            new Department { Name = "ИТ", Employees = new List<string> { "Иван", "Петр" } },
            new Department { Name = "HR", Employees = new List<string> { "Мария", "Анна" } }
        };

        // Решение задачи 6 - SelectMany
        var allEmployees = departments.SelectMany(d => d.Employees);

        // Вывод результатов
        Console.WriteLine("Все сотрудники из всех отделов:");
        Console.WriteLine(string.Join(", ", allEmployees));
    }
}