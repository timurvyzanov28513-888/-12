﻿using System;
using System.Linq;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<int> allItems = Enumerable.Range(1, 100).ToList(); // 1, 2, 3, ... 100
        int pageNumber = 3;
        int pageSize = 10;

        // Решение задачи 8
        var pageItems = allItems
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize);

        // Вывод результатов
        Console.WriteLine($"Страница {pageNumber}, размер страницы {pageSize}:");
        Console.WriteLine(string.Join(", ", pageItems));
    }
}