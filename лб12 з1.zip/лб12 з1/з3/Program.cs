﻿using System;
using System.Linq;
using System.Collections.Generic;

class Product
{
    public string Name { get; set; }
    public string Category { get; set; }
    public decimal Price { get; set; }
}

class Program
{
    static void Main()
    {
        List<Product> products = new List<Product>
        {
            new Product { Name = "Телефон", Category = "Электроника", Price = 500 },
            new Product { Name = "Ноутбук", Category = "Электроника", Price = 1000 },
            new Product { Name = "Стул", Category = "Мебель", Price = 150 },
            new Product { Name = "Стол", Category = "Мебель", Price = 300 },
            new Product { Name = "Книга", Category = "Книжная", Price = 20 }
        };

        // Решение задачи 3
        var groupedProducts = products
            .GroupBy(p => p.Category)
            .Select(group => new
            {
                Category = group.Key,
                AvgPrice = group.Average(p => p.Price),
                Count = group.Count()
            });

        // Вывод результатов
        foreach (var item in groupedProducts)
        {
            Console.WriteLine($"Группа \"{item.Category}\": AvgPrice = {item.AvgPrice}, Count = {item.Count}");
        }
    }
}