﻿List<string> words = new List<string> { "Яблоко", "Апельсин", "Ананас", "Банан", "Абрикос" };

var result = words
    .Where(w => w.StartsWith("А", StringComparison.OrdinalIgnoreCase))
    .OrderByDescending(w => w.Length)
    .FirstOrDefault();

if (result != null)
    Console.WriteLine(result);
else
    Console.WriteLine("Строк на 'А' не найдено");
