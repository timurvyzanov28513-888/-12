﻿using System;
using System.Linq;
using System.Collections.Generic;

class Student
{
    public string Name { get; set; }
    public int Grade { get; set; }
}

class Program
{
    static void Main()
    {
        List<Student> students = new List<Student>
        {
            new Student { Name = "Алексей", Grade = 85 },
            new Student { Name = "Светлана", Grade = 92 },
            new Student { Name = "Дмитрий", Grade = 78 },
            new Student { Name = "Ольга", Grade = 96 }
        };

        // Решение задачи 7
        bool allPassed = students.All(s => s.Grade > 50);
        bool hasExcellent = students.Any(s => s.Grade >= 95);

        // Вывод результатов
        Console.WriteLine($"allPassed = {allPassed}");
        Console.WriteLine($"hasExcellent = {hasExcellent}");
    }
}