﻿using System;
using System.Linq;
using System.Collections.Generic;

class Item
{
    public int Id { get; set; }
    public string Value { get; set; }
}

class Program
{
    static void Main()
    {
        List<Item> items = new List<Item>
        {
            new Item { Id = 1, Value = "Первый" },
            new Item { Id = 2, Value = "Второй" },
            new Item { Id = 3, Value = "Третий" },
            new Item { Id = 2, Value = "Дубликат" }, // дублирующийся ключ
            new Item { Id = 4, Value = "Четвертый" },
            new Item { Id = 5, Value = "Пятый" },
            new Item { Id = 2, Value = "Еще дубликат" } // еще дубликат
        };

        // Решение задачи 9 - с обработкой дубликатов (берем первый)
        var dictionary = items
            .GroupBy(i => i.Id)
            .ToDictionary(g => g.Key, g => g.First());

        // Вывод результатов
        Console.WriteLine("Словарь (ключ -> значение):");
        foreach (var kvp in dictionary)
        {
            Console.WriteLine($"Id: {kvp.Key} -> Value: {kvp.Value.Value}");
        }

        // Проверка для Id=2
        Console.WriteLine($"\nДля Id=2 значение: {dictionary[2].Value}");
    }
}