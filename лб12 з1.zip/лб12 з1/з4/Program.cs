﻿using System;
using System.Linq;
using System.Collections.Generic;

class Customer
{
    public int Id { get; set; }
    public string Name { get; set; }
}

class Order
{
    public int Id { get; set; }
    public int CustomerId { get; set; }
    public string Product { get; set; }
}

class Program
{
    static void Main()
    {
        List<Customer> customers = new List<Customer>
        {
            new Customer { Id = 1, Name = "Иван" },
            new Customer { Id = 2, Name = "Мария" }
        };

        List<Order> orders = new List<Order>
        {
            new Order { Id = 1, CustomerId = 1, Product = "Компьютер" },
            new Order { Id = 2, CustomerId = 2, Product = "Мышь" },
            new Order { Id = 3, CustomerId = 1, Product = "Клавиатура" }
        };

        // Решение задачи 4 - Join (синтаксис методов)
        var result = orders.Join(
            customers,
            order => order.CustomerId,
            customer => customer.Id,
            (order, customer) => new
            {
                OrderId = order.Id,
                Product = order.Product,
                CustomerName = customer.Name
            });

        // Вывод результатов
        Console.WriteLine("Список заказов с именем клиента:");
        Console.WriteLine("--------------------------------");
        foreach (var item in result)
        {
            Console.WriteLine($"OrderId: {item.OrderId}, Product: {item.Product}, CustomerName: {item.CustomerName}");
        }
    }
}