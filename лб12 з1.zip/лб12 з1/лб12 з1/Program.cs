﻿int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

var result = numbers
    .Where (x => x % 2 == 0)
    .Select (x => x * x)
    .OrderBy(x => x)
    .ToList();

Console.WriteLine(String.Join(",",result));