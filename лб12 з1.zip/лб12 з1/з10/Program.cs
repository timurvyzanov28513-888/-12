﻿using System;
using System.Linq;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        string[] sentences = {
            "Привет, как дела?",
            "Привет, а у тебя как дела?",
            "А у меня все отлично!"
        };

        // Решение задачи 10
        var wordStats = sentences
            .SelectMany(s => s.Split(new[] { ' ', ',', '?', '!', '.', ';', ':', '-' },
                                    StringSplitOptions.RemoveEmptyEntries))
            .Select(word => word.ToLower())
            .GroupBy(word => word)
            .Select(group => new { Word = group.Key, Count = group.Count() })
            .OrderByDescending(x => x.Count);

        // Вывод результатов
        Console.WriteLine("Список пар { Слово, Количество }:");
        Console.WriteLine("--------------------------------");
        foreach (var item in wordStats)
        {
            Console.WriteLine($"(\"{item.Word}\", {item.Count})");
        }
    }
}