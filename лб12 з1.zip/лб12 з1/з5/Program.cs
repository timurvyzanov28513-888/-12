﻿using System;
using System.Linq;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<int> list1 = new List<int> { 1, 2, 3, 4, 5, 6 };
        List<int> list2 = new List<int> { 4, 5, 6, 7, 8, 9 };

        // Решение задачи 5 - способ 1 (метод Except)
        var result = list1.Except(list2);

        // Вывод результатов
        Console.WriteLine("Числа из первого списка, которых нет во втором:");
        Console.WriteLine(string.Join(", ", result));
    }
}